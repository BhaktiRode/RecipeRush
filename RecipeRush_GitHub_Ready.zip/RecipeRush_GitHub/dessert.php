<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Database connection failed");
}

// fetch dessert items
$result = mysqli_query($conn,"SELECT * FROM products WHERE category='dessert'");

/* ✅ CART COUNT FROM DATABASE */
$count = 0;

if(isset($_SESSION['user'])){
    $user = mysqli_real_escape_string($conn, $_SESSION['user']);

    $res = mysqli_query($conn,"SELECT SUM(qty) as total FROM cart WHERE username='$user'");
    
    if($res){
        $row = mysqli_fetch_assoc($res);
        $count = (!empty($row['total'])) ? $row['total'] : 0;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Recipe Rush - Dessert</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600&family=Playfair+Display:wght@700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root { --primary-orange:#f28d61; --bg-cream:#fdf6f4; }

body{font-family:'Outfit',sans-serif;background:var(--bg-cream);}
h1,h2{font-family:'Playfair Display',serif;}

.main-container{
background:white;
border-radius:2.5rem;
box-shadow:0 20px 40px rgba(0,0,0,0.05);
margin-top:2rem;margin-bottom:2rem;
}

.navbar-brand{font-weight:bold;font-size:22px;}

.cart-badge{
position:absolute;
top:-6px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
}

.carousel-item img{
height:700px;
object-fit:cover;
}

.recipe-card{
border:none;
border-radius:1.5rem;
background:#fff9f7;
overflow:hidden;
box-shadow:0 4px 15px rgba(0,0,0,0.05);
transition:0.3s;
}

.recipe-card:hover{transform:translateY(-5px);}
.recipe-card img{height:350px;object-fit:cover;}

.time-badge{font-size:0.8rem;color:#888;}
.dot{width:8px;height:8px;border-radius:50%;display:inline-block;}
</style>
</head>

<body>

<div class="container main-container py-4 px-lg-5">

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm" style="border-radius:0.5cm;">
<div class="container-fluid px-3">

<a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span style="color:rgb(100,99,99);">Recipe<span style="color:orange;">Rush</span></span>
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarNav">

<ul class="navbar-nav me-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
<li class="nav-item"><a class="nav-link" href="index.php#trending">Trending</a></li>
</ul>

<div class="d-flex align-items-center gap-3">

<form class="d-flex" method="GET" action="search.php">
<input class="form-control me-2" type="search" name="q" placeholder="Search recipes">
<button class="btn btn-success px-3">Search</button>
</form>

<!-- ✅ CART -->
<a href="cart.php" style="position:relative;">
🛒
<span class="cart-badge"><?php echo $count; ?></span>
</a>

<?php if(isset($_SESSION['user'])){ ?>
<span class="nav-link">Welcome, <?php echo $_SESSION['user']; ?></span>
<a href="user-logout.php" class="btn btn-danger">Logout</a>
<?php } else { ?>
<a href="user-login.php" class="nav-link">Login</a>
<a href="signup.php" class="btn btn-warning px-3">Signup</a>
<?php } ?>

</div>
</div>
</div>
</nav>

<!-- MAIN -->

<h1 class="text-center mb-4">Dessert</h1>

<!-- CAROUSEL -->
<div id="carouselExample" class="carousel slide" data-bs-ride="carousel" data-bs-interval="2000">
<div class="carousel-inner">

<div class="carousel-item active">
<img src="carousel7.jpg" class="d-block w-100 rounded">
</div>

<div class="carousel-item">
<img src="carousel8.jpg" class="d-block w-100 rounded">
</div>

<div class="carousel-item">
<img src="carousel9.jpg" class="d-block w-100 rounded">
</div>

</div>
</div>

<!-- RECIPES -->
<div class="mt-5 pt-4">
<h2 class="text-center mb-4">Popular Dessert Recipes</h2>

<div class="row g-4">

<?php
if(mysqli_num_rows($result) > 0){
while($row = mysqli_fetch_assoc($result)){
?>

<div class="col-md-4">
<div class="card recipe-card">

<img src="<?php echo $row['image']; ?>" alt="recipe">

<div class="card-body">
<a href="recipe.php?id=<?php echo $row['id']; ?>">
<h5 class="fw-bold"><?php echo $row['name']; ?></h5>
</a>

<div class="time-badge">
<span class="dot" style="background:#8fb25a"></span>
<?php echo isset($row['time']) ? $row['time'] : '15 mins'; ?>
</div>

</div>

</div>
</div>

<?php
}
}else{
echo "<p class='text-center'>No dessert recipes found</p>";
}
?>

</div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>