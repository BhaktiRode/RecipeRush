<?php
session_start();

$count = 0;

if(isset($_SESSION['cart'])){
    foreach($_SESSION['cart'] as $item){
        if(is_array($item) && isset($item['qty'])){
            $count += $item['qty'];
        } else {
            $count++;
        }
    }
}
