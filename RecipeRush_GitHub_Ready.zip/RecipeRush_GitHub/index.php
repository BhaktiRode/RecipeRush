<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Database connection failed");
}

/* ✅ CART COUNT FROM DATABASE */
$count = 0;

if(isset($_SESSION['user'])){
    $user = mysqli_real_escape_string($conn, $_SESSION['user']);

    $res = mysqli_query($conn,"SELECT SUM(qty) as total FROM cart WHERE username='$user'");
    
    if($res){
        $row = mysqli_fetch_assoc($res);
        $count = (!empty($row['total'])) ? $row['total'] : 0;
    }
}

/* TRENDING */
$result = mysqli_query($conn,"
SELECT * FROM products 
ORDER BY views DESC 
LIMIT 3
");
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Recipe Rush</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet">

<style>
*{font-family:'Playfair Display',serif;}
html{scroll-behavior:smooth;}

.navbar-brand{font-weight:bold;font-size:22px;}

.cart-badge{
position:absolute;
top:-6px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
}

.hero{
background:url("image1.png") center/cover no-repeat;
height:600px;
display:flex;
align-items:center;
}

.hero-content{max-width:600px;margin-left:10%;}
.hero h1{font-size:3rem;color:black;}
.hero p{color:black;}

.category-card img{
border-radius:10px;
width:100%;
height:220px;
object-fit:cover;
}

.category-card h5{margin-top:10px;color:#fb6b2a;}

.recipe-card{
border-radius:10px;
overflow:hidden;
background:#fff;
box-shadow:0 4px 12px rgba(0,0,0,0.05);
transition:.2s;
}

.recipe-card:hover{transform:scale(1.03);}

.recipe-card img{
width:100%;
height:200px;
object-fit:cover;
}

.recipe-card-body{padding:15px;}

.recipe-card .btn{
background:#fb6b2a;
color:white;
border-radius:25px;
margin:3px;
}
    input:focus{
    box-shadow:none;
    border-color:#ff7a00;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm" style="border-radius:0.5cm;">
<div class="container-fluid px-3">

<a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span style="color:rgb(100,99,99);">Recipe<span style="color:orange;">Rush</span></span>
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarNav">

<ul class="navbar-nav me-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
<li class="nav-item"><a class="nav-link" href="index.php#trending">Trending</a></li>
</ul>

<div class="d-flex align-items-center gap-3">

<form class="d-flex" method="GET" action="search.php">
<input class="form-control me-2" type="search" name="q" placeholder="Search recipes">
<button class="btn btn-success px-3">Search</button>
</form>

<!-- ✅ CART -->
<a href="cart.php" style="position:relative;">
🛒
<span class="cart-badge"><?php echo $count; ?></span>
</a>

<?php if(isset($_SESSION['user'])){ ?>
<span class="nav-link">Welcome, <?php echo $_SESSION['user']; ?></span>
<a href="user-logout.php" class="btn btn-danger">Logout</a>
<?php } else { ?>
<a href="user-login.php" class="nav-link">Login</a>
<a href="signup.php" class="btn btn-warning px-3">Signup</a>
<?php } ?>

</div>
</div>
</div>
</nav>

<!-- HERO -->
<section class="hero">
<div class="hero-content">
<h1>Welcome to Recipe Rush</h1>
<p>Discover delicious recipes and shop ingredients instantly.</p>
</div>
</section>

<!-- CATEGORIES -->
<section class="container my-5 text-center">
<h2 class="fw-bold mb-4">Explore Categories</h2>

<div class="row g-4">

<div class="col-md-3">
<div class="category-card">
<a href="breakfast.php"><img src="breakfast.jpg"></a>
<h5>Breakfast</h5>
</div>
</div>

<div class="col-md-3">
<div class="category-card">
<a href="lunch.php"><img src="lunch1.jpeg"></a>
<h5>Lunch</h5>
</div>
</div>

<div class="col-md-3">
<div class="category-card">
<a href="dinner.php"><img src="dinner.jpeg"></a>
<h5>Dinner</h5>
</div>
</div>

<div class="col-md-3">
<div class="category-card">
<a href="dessert.php"><img src="dessert.jpg"></a>
<h5>Desserts</h5>
</div>
</div>

</div>
</section>

<!-- TRENDING -->
<section id="trending" class="container my-5">
<h2 class="text-center fw-bold mb-4">Trending This Week</h2>

<div class="row g-4">

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<div class="col-md-4">
<div class="recipe-card">

<img src="<?php echo $row['image']; ?>" class="img-fluid">

<div class="recipe-card-body">
<h5><?php echo $row['name']; ?></h5>
<p>Fresh & delicious recipe.</p>

<a href="recipe.php?id=<?php echo $row['id']; ?>" class="btn">
View Recipe
</a>

</div>
</div>
</div>

<?php } ?>

</div>
</section>

<!-- HOW IT WORKS -->
<section id="how" class="text-center my-5">
<div class="container">
<h2 class="fw-bold mb-5">How It Works</h2>

<div class="row g-4">

<div class="col-md-4">
<a href="categories.php"><img src="browse.jpeg" width="60"></a>
<h5 class="fw-bold mt-2">Browse Recipes</h5>
<p class="text-muted">Explore recipes categorized for easy cooking.</p>
</div>

<div class="col-md-4">
<a href="categories.php"><img src="video.png" width="60"></a>
<h5 class="fw-bold mt-2">Watch Videos</h5>
<p class="text-muted">Follow step-by-step cooking instructions.</p>
</div>

<div class="col-md-4">
<a href="categories.php"><img src="shop.png" width="60"></a>
<h5 class="fw-bold mt-2">Shop Ingredients</h5>
<p class="text-muted">Buy ingredients easily from trusted platforms.</p>
</div>

</div>
</div>
</section>
<footer class="text-dark pt-4 pb-3 border-top text-center"
style="background-color:rgb(250,202,148);">

<div class="container">

<!-- LINKS -->
<div class="mb-3">
<a href="about.php" class="mx-3 text-dark text-decoration-none">About Us</a>
<a href="contact.php" class="mx-3 text-dark text-decoration-none">Contact</a>
<a href="privacy.php" class="mx-3 text-dark text-decoration-none">Privacy Policy</a>
<a href="feedback.php" class="mx-3 text-dark text-decoration-none">Feedback</a>
</div>

<!-- DIVIDER -->
<hr style="width:50%;margin:auto;opacity:0.3;">

<!-- FEEDBACK FORM -->
<div class="mt-4">
<form method="POST" action="feedback-submit.php" class="mx-auto" style="max-width:500px;">

<div class="input-group">

<input type="text" name="message" class="form-control"
placeholder="Write your feedback..." required
style="border-radius:25px 0 0 25px; padding:10px;">

<button class="btn"
style="background:#ff7a00;color:white;border-radius:0 25px 25px 0;padding:10px 20px;">
Submit
</button>

</div>

</form>
</div>

<p class="mt-3">© 2026 Recipe Rush | All Rights Reserved</p>

</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>