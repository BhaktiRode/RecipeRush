<?php
session_start();
$count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;

/* CART COUNT */
$count = 0;
if($user){
$res = mysqli_query($conn,"SELECT SUM(qty) as total FROM cart WHERE username='$user'");
$row = mysqli_fetch_assoc($res);
$count = $row['total'] ? $row['total'] : 0;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recipe Rush - Contact Us</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
--primary-orange:#eb8a5d;
--bg-pink:#fdf2f0;
--text-dark:#5a5a5a;
--card-bg:rgba(255,255,255,0.6);
}

body{
background:var(--bg-pink);
background-image:url('https://www.transparenttextures.com/patterns/paper-fibers.png');
font-family:'Poppins',sans-serif;
color:var(--text-dark);
}

.serif-font{
font-family:'Playfair Display',serif;
}

.navbar-brand{
font-weight:bold;
font-size:22px;
}

.cart-badge{
position:absolute;
top:-6px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
}

.hero-img{
width:100%;
height:500px;
object-fit:cover;
border-radius:20px;
}

.contact-card{
background:var(--card-bg);
border-radius:15px;
padding:40px 20px;
box-shadow:0 10px 30px rgba(0,0,0,0.02);
}

.icon-box{
font-size:2rem;
color:var(--primary-orange);
margin-bottom:15px;
}

footer{
margin-top:80px;
padding-bottom:40px;
}

footer a{
text-decoration:none;
color:var(--text-dark);
margin:0 15px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm" style="border-radius:0.5cm;">
<div class="container-fluid px-3">

<a class="navbar-brand d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span>Recipe<span style="color:orange;">Rush</span></span>
</a>

<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="nav">

<ul class="navbar-nav me-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
<li class="nav-item"><a class="nav-link" href="index.php#trending">Trending</a></li>
</ul>

<div class="d-flex align-items-center gap-3">

<form class="d-flex" method="GET" action="search.php">
<input class="form-control me-2" type="search" name="q" placeholder="Search recipes">
<button class="btn btn-success px-3">Search</button>
</form>

<a href="cart.php" style="position:relative; text-decoration:none; font-size:20px; color:black;">
🛒
<span style="
position:absolute;
top:-6px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
">
<?php echo $count; ?>
</span>
</a>

<?php if($user){ ?>
<span class="nav-link">Welcome, <?php echo $user; ?></span>
<a href="user-logout.php" class="btn btn-danger">Logout</a>
<?php } else { ?>
<a href="user-login.php" class="nav-link">Login</a>
<a href="signup.php" class="btn btn-warning px-3">Signup</a>
<?php } ?>

</div>
</div>
</div>
</nav>

<!-- MAIN -->
<main class="container text-center my-5">

<h1 class="display-4 serif-font mb-5">Contact Us</h1>

<img src="contact.jpg" class="hero-img mb-5">

<div class="row g-4 justify-content-center">

<div class="col-md-3">
<div class="contact-card">
<div class="icon-box"><i class="fa fa-envelope"></i></div>
<h5>Email Us</h5>
<p>info@reciperush.com</p>
</div>
</div>

<div class="col-md-3">
<div class="contact-card">
<div class="icon-box"><i class="fa fa-phone"></i></div>
<h5>Call Us</h5>
<p>+91 9876543210</p>
</div>
</div>

<div class="col-md-3">
<div class="contact-card">
<div class="icon-box"><i class="fa fa-location-dot"></i></div>
<h5>Visit Us</h5>
<p>Mumbai, India</p>
</div>
</div>

</div>

</main>

<!-- FOOTER -->
<footer class="text-center">
<div class="container">

<div class="mb-3">
<a href="about.php">About Us</a>
<a href="contact.php">Contact</a>
<a href="privacy.php">Privacy Policy</a>
    <a href="feedback.php" class="mx-3 text-dark text-decoration-none">Feedback</a>
</div>

<p class="text-muted">© 2026 Recipe Rush</p>

</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>