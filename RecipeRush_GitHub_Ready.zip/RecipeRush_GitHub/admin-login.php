<?php
session_start();

if(isset($_POST['login'])){

    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hardcoded admin credentials
    $admin_user = "admin";
    $admin_pass = "admin123";

    if($username == $admin_user && $password == $admin_pass){

        $_SESSION['admin'] = $username;

        header("Location: admin-dashboard.php");
        exit();

    } else {
        $error = "Invalid Username or Password";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Admin Login</title>
</head>

<body>

<?php if(isset($error)){ echo "<p style='color:red;'>$error</p>"; } ?>

</body>
</html>