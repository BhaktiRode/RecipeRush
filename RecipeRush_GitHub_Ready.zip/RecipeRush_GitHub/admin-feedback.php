<?php
session_start();

if(!isset($_SESSION['admin'])){
    header("Location: admin-login.html");
    exit();
}

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed");
}

/* DELETE */
if(isset($_GET['delete'])){
    $id = intval($_GET['delete']);
    mysqli_query($conn,"DELETE FROM feedback WHERE id=$id");
}

/* FETCH */
$result = mysqli_query($conn,"SELECT * FROM feedback ORDER BY created_at DESC");
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Feedback</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
    background:#fdf6f0;
    font-family:'Playfair Display',serif;
}

/* NAVBAR */
.navbar{
    background:#f8e8d8;
    border-radius:0.5cm;
}

/* CONTAINER */
.main-box{
    background:#f8e8d8;
    padding:30px;
    border-radius:20px;
    margin-top:40px;
}

/* CARD */
.feedback-card{
    background:white;
    border-radius:15px;
    padding:15px 20px;
    margin-bottom:15px;
    box-shadow:0 4px 10px rgba(0,0,0,0.05);
    transition:0.2s;
}

.feedback-card:hover{
    transform:translateY(-3px);
}

/* TEXT */
.username{
    font-weight:bold;
    font-size:18px;
}

.message{
    margin:5px 0;
}

.date{
    font-size:13px;
    color:gray;
}

/* DELETE BTN */
.delete-btn{
    background:#ff4d4d;
    color:white;
    border:none;
    padding:5px 12px;
    border-radius:20px;
    font-size:13px;
}

.delete-btn:hover{
    background:#e60000;
}
</style>

</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg shadow-sm p-3">
<div class="container-fluid">

<h4>Admin Panel</h4>

<div class="ms-auto">
<a href="admin-dashboard.php" class="btn btn-secondary me-2">Dashboard</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>

</div>
</nav>

<!-- CONTENT -->
<div class="container">

<h2 class="text-center mt-4">Manage Feedback</h2>

<div class="main-box">

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<div class="feedback-card">

<div class="username">
<?php echo $row['username']; ?>
</div>

<div class="message">
<?php echo $row['message']; ?>
</div>

<div class="date">
<?php echo date("d M Y, h:i A", strtotime($row['created_at'])); ?>
</div>

<a href="?delete=<?php echo $row['id']; ?>" 
   onclick="return confirm('Delete this feedback?')">
<button class="delete-btn mt-2">Delete</button>
</a>

</div>

<?php } ?>

</div>

</div>

</body>
</html>