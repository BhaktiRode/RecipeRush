<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed");
}

if(!isset($_SESSION['user'])){
header("Location: user-login.php");
exit();
}

$user = $_SESSION['user'];

$result = mysqli_query($conn,"
SELECT * FROM orders 
WHERE customer='$user' 
ORDER BY id DESC
");
?>

<!DOCTYPE html>
<html>
<head>
<title>Order History</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<div class="container mt-5">

<h2 class="mb-4">My Orders 🧾</h2>

<?php if(mysqli_num_rows($result)==0){ ?>
<p>No orders found</p>
<?php } else { ?>

<table class="table table-bordered">
<tr>
<th>Product</th>
<th>Amount</th>
<th>Status</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<tr>
<td><?php echo $row['product']; ?></td>
<td>₹ <?php echo $row['amount']; ?></td>
<td><?php echo $row['status']; ?></td>
</tr>

<?php } ?>

</table>

<?php } ?>

</div>

</body>
</html>