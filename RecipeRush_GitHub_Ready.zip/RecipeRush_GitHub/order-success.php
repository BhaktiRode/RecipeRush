<?php
session_start();

/* ✅ TIMEZONE FIX */
date_default_timezone_set('Asia/Kolkata');

/* ✅ SHOW ERRORS (REMOVE AFTER TESTING) */
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* DATABASE */
$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed: " . mysqli_connect_error());
}

/* ✅ SAFE ID */
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

/* ✅ QUERY */
$result = mysqli_query($conn,"SELECT * FROM orders WHERE id=$id");

/* ✅ CHECK QUERY ERROR */
if(!$result){
die("Query Error: " . mysqli_error($conn));
}

/* ✅ FETCH DATA */
$order = mysqli_fetch_assoc($result);

/* ✅ HANDLE INVALID ORDER */
if(!$order){
die("Invalid Order ID");
}

/* USER */
$user = isset($_SESSION['user']) ? $_SESSION['user'] : "Guest";
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recipe Rush - Order Success</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
background:#f3f3f3;
font-family:'Segoe UI', sans-serif;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.success-container{
background:#ffffff;
padding:50px 40px;
border-radius:25px;
width:420px;
text-align:center;
box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

.success-icon{
font-size:60px;
margin-bottom:15px;
}

.success-title{
font-size:28px;
font-weight:500;
margin-bottom:10px;
}

.success-text{
color:#666;
margin-bottom:10px;
}

.order-id{
font-weight:600;
margin-bottom:10px;
}

.home-btn{
background:linear-gradient(90deg,#ff5a00,#ff9a4d);
border:none;
padding:12px;
border-radius:30px;
width:100%;
color:white;
font-size:16px;
}
</style>
</head>

<body>

<div class="success-container">

<div class="logo mb-3">
<img src="foodlogo.png" width="40">
Recipe <span style="color:orange;">Rush</span>
</div>

<div class="success-icon">🎉</div>

<div class="success-title">
Order Placed Successfully!
</div>

<p class="success-text">
Thank you, <b><?php echo $user; ?></b>! Your food will arrive soon.
</p>

<!-- ✅ ORDER DETAILS -->
<div class="order-id">
Order ID: #<?php echo $order['id']; ?>
</div>

<p>Customer: <?php echo $order['customer']; ?></p>
<p>Total: ₹<?php echo $order['total_amount']; ?></p>
<p>Payment: <?php echo $order['payment_method']; ?></p>
<p>Status: <?php echo $order['status']; ?></p>

<!-- ✅ FORMATTED DATE -->
<p>
Date: <?php echo date("d M Y, h:i A", strtotime($order['order_date'])); ?>
</p>

<a href="index.php">
<button class="home-btn">
Back to Home
</button>
</a>

</div>

</body>
</html>