<?php
$conn = mysqli_connect("sql100.infinityfree.com","if0_41421772","ZhTezeJRMZeRYqb","if0_41421772_reciperush");

$id = $_GET['id'];

mysqli_query($conn,"DELETE FROM cart WHERE id=$id");

header("Location: cart.php");
?>