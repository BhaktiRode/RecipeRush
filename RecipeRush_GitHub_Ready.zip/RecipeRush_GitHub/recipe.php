<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Database connection failed");
}

/* ✅ CART COUNT */
$count = 0;

if(isset($_SESSION['user'])){
    $user = mysqli_real_escape_string($conn, $_SESSION['user']);

    $res = mysqli_query($conn,"SELECT SUM(qty) as total FROM cart WHERE username='$user'");
    
    if($res){
        $row = mysqli_fetch_assoc($res);
        $count = (!empty($row['total'])) ? $row['total'] : 0;
    }
}

// SAFE ID
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

/* ADD VIEW COUNT */
mysqli_query($conn,"UPDATE products SET views = views + 1 WHERE id=$id");

// FETCH PRODUCT
$product = mysqli_query($conn,"SELECT * FROM products WHERE id=$id");
$data = mysqli_fetch_assoc($product);

// ADD TO CART
if(isset($_POST['add_to_cart'])){

$username = isset($_SESSION['user']) ? $_SESSION['user'] : 'guest';

if(isset($_POST['ingredient'])){
foreach($_POST['ingredient'] as $index){

$name = $_POST['name'][$index];
$price = $_POST['price'][$index];
$qty = $_POST['qty'][$index];

$check = mysqli_query($conn,"SELECT * FROM cart 
WHERE username='$username' AND product_name='$name'");

if(mysqli_num_rows($check) > 0){

mysqli_query($conn,"UPDATE cart 
SET qty = qty + $qty 
WHERE username='$username' AND product_name='$name'");

}else{

mysqli_query($conn,"INSERT INTO cart (username, product_name, price, qty)
VALUES ('$username','$name','$price','$qty')");
}
}
}

echo "<script>alert('Added to cart'); window.location='cart.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title><?php echo $data['name']; ?></title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&family=Quicksand:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
--foodhub-orange:#e67e22;
--paper-color:#f4e4d4;
--text-main:#4a3f35;
}

body{
background:#e5d1bc;
font-family:'Quicksand',sans-serif;
color:var(--text-main);
padding:20px 0;
}

.recipe-page{
max-width:1200px;
margin:auto;
background:var(--paper-color);
padding:40px;
border-radius:15px;
box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

/* NAVBAR */
.cart-badge{
position:absolute;
top:-8px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
}

/* TITLE */
h1{
font-family:'Playfair Display',serif;
font-size:42px;
}

.description{
font-style:italic;
margin-bottom:30px;
}

/* VIDEO */
.hero-box iframe{
width:100%;
height:500px;
border-radius:12px;
margin-bottom:40px;
}

/* INGREDIENT */
.ingredient-row{
display:flex;
justify-content:space-between;
align-items:center;
margin-bottom:10px;
}

/* BUTTON */
.btn-buy{
background:var(--foodhub-orange);
color:white;
border:none;
padding:10px 20px;
border-radius:20px;
margin-top:10px;
}

/* CARD */
.card img{
height:180px;
object-fit:cover;
}

/* STEPS */
ol li{
margin-bottom:8px;
}
</style>

</head>

<body>

<div class="recipe-page">

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm mb-4" style="border-radius:10px;">
<div class="container-fluid">

<a class="navbar-brand" href="index.php">
Recipe<span style="color:orange;">Rush</span>
</a>

<div class="ms-auto position-relative">

<a href="cart.php" class="text-dark position-relative" style="font-size:22px;">
<i class="fa fa-shopping-cart"></i>

<!-- ✅ CART COUNT -->
<?php if($count > 0){ ?>
<span class="cart-badge"><?php echo $count; ?></span>
<?php } ?>

</a>

</div>

</div>
</nav>

<!-- TITLE -->
<h1><?php echo $data['name']; ?></h1>

<p class="description">
<?php echo $data['description']; ?>
</p>

<!-- VIDEO -->
<div class="hero-box">
<iframe src="<?php echo $data['video']; ?>" allowfullscreen></iframe>
</div>

<div class="row">

<!-- INGREDIENTS -->
<div class="col-md-5">

<h2>Ingredients</h2>

<form method="POST">

<?php
$ingredients = mysqli_query($conn,"SELECT * FROM ingredients WHERE product_id=$id");

while($row = mysqli_fetch_assoc($ingredients)){
?>

<div class="ingredient-row">

<label>
<input type="checkbox" name="ingredient[]" value="<?php echo $row['id']; ?>">
<?php echo $row['name']; ?> ₹<?php echo $row['price']; ?>
</label>

<input type="hidden" name="name[<?php echo $row['id']; ?>]" value="<?php echo $row['name']; ?>">
<input type="hidden" name="price[<?php echo $row['id']; ?>]" value="<?php echo $row['price']; ?>">
<input type="number" name="qty[<?php echo $row['id']; ?>]" value="1" min="1">

</div>

<?php } ?>

<button name="add_to_cart" class="btn-buy">
Add to Cart
</button>

</form>

</div>

<!-- INSTRUCTIONS -->
<div class="col-md-7">

<h2>Instructions</h2>

<?php
$instructions = $data['instructions'];

if(strpos($instructions, '<p>') !== false){
    echo $instructions;
}else{
    $steps = explode('.', $instructions);

    echo "<ol>";
    foreach($steps as $step){
        $step = trim($step);
        if(!empty($step)){
            echo "<li>$step</li>";
        }
    }
    echo "</ol>";
}
?>

</div>

</div>

<!-- RECOMMENDED -->
<hr class="mt-5">

<h2>Recommended Recipes</h2>

<div class="row">

<?php
$cat = $data['category'];

$res = mysqli_query($conn,"SELECT * FROM products WHERE category='$cat' AND id!=$id LIMIT 3");

while($row = mysqli_fetch_assoc($res)){
?>

<div class="col-md-4">
<div class="card shadow-sm">

<img src="<?php echo $row['image']; ?>">

<div class="card-body">
<h6><?php echo $row['name']; ?></h6>

<a href="recipe.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-dark">
View
</a>

</div>

</div>
</div>

<?php } ?>

</div>

</div>

</body>
</html>