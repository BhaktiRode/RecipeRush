<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Database connection failed");
}

$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;

/* ✅ CART COUNT FROM DATABASE */
$count = 0;

if($user){
    $user = mysqli_real_escape_string($conn, $user);

    $res = mysqli_query($conn,"SELECT SUM(qty) as total FROM cart WHERE username='$user'");
    
    if($res){
        $row = mysqli_fetch_assoc($res);
        $count = (!empty($row['total'])) ? $row['total'] : 0;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recipe Rush - Privacy Policy</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root {
--primary-orange:#eb8a5d;
--bg-texture:#fdf2f0;
--text-muted:#6c757d;
--accent-green:#96a17b;
}

body{
background-color:var(--bg-texture);
background-image:url('https://www.transparenttextures.com/patterns/paper-fibers.png');
font-family:'Poppins',sans-serif;
color:#4a4a4a;
}

.serif-font{
font-family:'Playfair Display',serif;
}

.navbar-brand{
font-weight:bold;
font-size:22px;
}

.cart-badge{
position:absolute;
top:-6px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
}

.policy-card{
background:rgba(255,255,255,0.4);
border-radius:15px;
padding:40px;
box-shadow:0 10px 30px rgba(0,0,0,0.02);
}

.section-title{
color:#b56b4d;
font-weight:600;
margin-top:25px;
}

footer{
margin-top:80px;
padding-bottom:40px;
}

footer a{
text-decoration:none;
color:var(--text-muted);
margin:0 10px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm" style="border-radius:0.5cm;">
<div class="container-fluid px-3">

<a class="navbar-brand d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span>Recipe<span style="color:orange;">Rush</span></span>
</a>

<button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#nav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="nav">

<ul class="navbar-nav me-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
<li class="nav-item"><a class="nav-link" href="index.php#trending">Trending</a></li>
</ul>

<div class="d-flex align-items-center gap-3">

<form class="d-flex" method="GET" action="search.php">
<input class="form-control me-2" type="search" name="q" placeholder="Search recipes">
<button class="btn btn-success px-3">Search</button>
</form>

<!-- ✅ CART -->
<a href="cart.php" style="position:relative;">
🛒
<span class="cart-badge"><?php echo $count; ?></span>
</a>

<?php if($user){ ?>
<span class="nav-link">Welcome, <?php echo $user; ?></span>
<a href="user-logout.php" class="btn btn-danger">Logout</a>
<?php } else { ?>
<a href="user-login.php" class="nav-link">Login</a>
<a href="signup.php" class="btn btn-warning px-3">Signup</a>
<?php } ?>

</div>
</div>
</div>
</nav>

<!-- MAIN -->
<div class="container py-5">

<h1 class="text-center serif-font display-5 mb-5">Privacy Policy</h1>

<div class="policy-card mx-auto" style="max-width:900px;">

<p class="text-center mb-4">
Your privacy is important to us at Recipe Rush. This Privacy Policy explains how we collect and protect your data.
</p>

<h5 class="section-title">1. Information We Collect</h5>
<ul>
<li>Name, email, and user details during signup</li>
<li>Browsing data for improving experience</li>
</ul>

<h5 class="section-title">2. How We Use Information</h5>
<ul>
<li>Improve services</li>
<li>Personalize experience</li>
<li>Respond to queries</li>
</ul>

<h5 class="section-title">3. Sharing Information</h5>
<ul>
<li>We do NOT sell your data</li>
<li>Only trusted services may access limited data</li>
</ul>

</div>

</div>

<!-- FOOTER -->
<footer class="text-center">
<div class="container">

<div class="mb-3">
<a href="about.php">About Us</a>
<a href="contact.php">Contact</a>
<a href="privacy.php">Privacy Policy</a>
    <a href="feedback.php" class="mx-3 text-dark text-decoration-none">Feedback</a>
</div>

<p class="text-muted">© 2026 Recipe Rush</p>

</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>