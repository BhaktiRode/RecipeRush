<?php
$conn = mysqli_connect("sql100.infinityfree.com","if0_41421772","ZhTezeJRMZeRYqb","if0_41421772_reciperush");

$id = $_GET['id'];
$action = $_GET['action'];

if($action == "inc"){
mysqli_query($conn,"UPDATE cart SET qty = qty + 1 WHERE id=$id");
}

if($action == "dec"){
mysqli_query($conn,"UPDATE cart SET qty = qty - 1 WHERE id=$id AND qty > 1");
}

header("Location: cart.php");
?>