<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
    die("Database connection failed");
}

/* ✅ CART COUNT FROM DATABASE */
$count = 0;

if(isset($_SESSION['user'])){
    $user = mysqli_real_escape_string($conn, $_SESSION['user']);

    $res = mysqli_query($conn,"SELECT SUM(qty) as total FROM cart WHERE username='$user'");
    
    if($res){
        $row = mysqli_fetch_assoc($res);
        $count = (!empty($row['total'])) ? $row['total'] : 0;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Recipe Rush - Categories</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
body{
    font-family: 'Outfit', sans-serif;
    background:#fdf6f4;
}

h1, h2{
    font-family:'Playfair Display', serif;
}

/* Navbar font */
.navbar, .nav-link, .navbar-brand{
    font-family: 'Outfit', sans-serif !important;
}

.cart-badge{
position:absolute;
top:-6px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
}

.main-container{
max-width:1000px;
background:white;
border-radius:30px;
box-shadow:0 10px 25px rgba(0,0,0,0.1);
overflow:hidden;
min-height:90vh;
padding:20px;
}

/* CATEGORY CARD */
.category-card{
border-radius:25px;
overflow:hidden;
background:#fff4ed;
transition:0.3s;
}

.category-card:hover{
transform:scale(1.02);
box-shadow:0 10px 25px rgba(0,0,0,0.15);
}

.category-card img{
width:100%;
height:350px;
object-fit:cover;
}
</style>

</head>

<body class="d-flex flex-column align-items-center p-4">
<div class="main-container w-100">

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm px-4 py-2 rounded-4">
<div class="container-fluid">

<!-- Logo -->
<a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span style="color:#666;">Recipe<span style="color:orange;">Rush</span></span>
</a>

<!-- Toggle -->
<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarNav">

<!-- LEFT MENU -->
<ul class="navbar-nav mx-auto gap-4">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link active fw-semibold" href="categories.php">Categories</a></li>
<li class="nav-item"><a class="nav-link" href="index.php#trending">Trending</a></li>
</ul>

<!-- RIGHT SIDE -->
<div class="d-flex align-items-center gap-4">

<!-- ✅ CART -->
<a href="cart.php" style="position:relative;">
🛒
<span class="cart-badge"><?php echo $count; ?></span>
</a>

<?php if(isset($_SESSION['user'])){ ?>
<span class="fw-semibold text-muted">Hi, <?php echo $_SESSION['user']; ?></span>
<a href="user-logout.php" class="btn btn-danger btn-sm px-3">Logout</a>
<?php } else { ?>
<a href="user-login.php" class="nav-link">Login</a>
<a href="signup.php" class="btn btn-warning px-3">Signup</a>
<?php } ?>

</div>

</div>
</div>
</nav>

<!-- MAIN -->
<h1 class="text-center mb-5">Explore Categories</h1>

<div class="row g-4 justify-content-center">

<!-- Breakfast -->
<div class="col-md-6">
<div class="category-card">
<a href="breakfast.php">
<img src="breakfast.jpeg">
</a>
<div class="py-3 text-center">
<span class="fw-semibold text-warning">Breakfast</span>
</div>
</div>
</div>

<!-- Lunch -->
<div class="col-md-6">
<div class="category-card">
<a href="lunch.php">
<img src="lunch.jpeg">
</a>
<div class="py-3 text-center">
<span class="fw-semibold text-dark">Lunch</span>
</div>
</div>
</div>

<!-- Dinner -->
<div class="col-md-6">
<div class="category-card">
<a href="dinner.php">
<img src="dinner.jpeg">
</a>
<div class="py-3 text-center">
<span class="fw-semibold text-warning">Dinner</span>
</div>
</div>
</div>

<!-- Dessert -->
<div class="col-md-6">
<div class="category-card">
<a href="dessert.php">
<img src="dessert.jpeg">
</a>
<div class="py-3 text-center">
<span class="fw-semibold text-warning">Dessert</span>
</div>
</div>
</div>

</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>