<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Database connection failed");
}

$user = isset($_SESSION['user']) ? $_SESSION['user'] : null;

/* ✅ CART COUNT FROM DATABASE */
$count = 0;

if($user){
    $user = mysqli_real_escape_string($conn, $user);

    $res = mysqli_query($conn,"SELECT SUM(qty) as total FROM cart WHERE username='$user'");
    
    if($res){
        $row = mysqli_fetch_assoc($res);
        $count = (!empty($row['total'])) ? $row['total'] : 0;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Recipe Rush - About Us</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@300;400;500&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
--primary-orange:#eb8a5d;
--bg-pink:#fdf2f0;
--text-dark:#5a5a5a;
--accent-green:#96a17b;
}

body{
background:var(--bg-pink);
font-family:'Poppins',sans-serif;
color:var(--text-dark);
margin:0;
}

.serif-font{
font-family:'Playfair Display',serif;
color:#4a4a4a;
}

.navbar-brand{
font-weight:bold;
font-size:22px;
}

.cart-badge{
position:absolute;
top:-6px;
right:-10px;
background:red;
color:white;
font-size:12px;
padding:2px 6px;
border-radius:50%;
}

.nav-link{
font-size:0.95rem;
margin:0 10px;
color:#666 !important;
}

.rounded-custom{
border-radius:20px;
box-shadow:0 10px 30px rgba(0,0,0,0.05);
width:100%;
object-fit:cover;
}

.hero-img{height:400px;}
.team-img{max-width:800px;}

footer{
margin-top:80px;
padding-bottom:40px;
font-size:0.9rem;
}

footer a{
text-decoration:none;
color:var(--text-dark);
margin:0 15px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm" style="border-radius:0.5cm;">
<div class="container-fluid px-3">

<a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span style="color: rgb(100,99,99);">Recipe<span style="color:orange;">Rush</span></span>
</a>

<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="navbarNav">

<ul class="navbar-nav me-auto">
<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
<li class="nav-item"><a class="nav-link" href="categories.php">Categories</a></li>
<li class="nav-item"><a class="nav-link" href="index.php#trending">Trending</a></li>
</ul>

<div class="d-flex align-items-center gap-3">

<form class="d-flex" method="GET" action="search.php">
<input class="form-control me-2" type="search" name="q" placeholder="Search recipes">
<button class="btn btn-success px-3">Search</button>
</form>

<a href="cart.php" style="position:relative;">
🛒
<span class="cart-badge"><?php echo $count; ?></span>
</a>

<?php if($user){ ?>
<span class="nav-link">Welcome, <?php echo $user; ?></span>
<a href="user-logout.php" class="btn btn-danger">Logout</a>
<?php } else { ?>
<a href="user-login.php" class="nav-link">Login</a>
<a href="signup.php" class="btn btn-warning px-3">Signup</a>
<?php } ?>

</div>
</div>
</div>
</nav>

<!-- HERO -->
<header class="container text-center my-5">
<h1 class="display-4 serif-font mb-5">About Us</h1>
<div class="row justify-content-center">
<div class="col-12">
<img src="about1.jpeg" class="rounded-custom hero-img">
</div>
</div>
</header>

<!-- CONTENT -->
<section class="container my-5 py-4">
<div class="row text-center g-4">

<div class="col-md-4">
<h3 class="serif-font h4 mb-3">Our Story</h3>
<p>RecipeRush was created with a passion for delicious food and easy cooking.</p>
</div>

<div class="col-md-4">
<h3 class="serif-font h4 mb-3">Our Mission</h3>
<p>To provide simple, tasty and practical recipes for everyday cooking.</p>
</div>

<div class="col-md-4">
<h3 class="serif-font h4 mb-3">Our Team</h3>
<p>Food lovers and chefs who ensure every recipe is perfect.</p>
</div>

</div>
</section>

<!-- TEAM IMAGE -->
<section class="container text-center my-5">
<img src="about2.jpg" class="rounded-custom team-img">
</section>

<!-- FOOTER -->
<footer class="text-center">
<div class="container">

<div class="mb-3">
<a href="about.php">About Us</a>
<a href="contact.php">Contact</a>
<a href="privacy.php">Privacy Policy</a>
    <a href="feedback.php" class="mx-3 text-dark text-decoration-none">Feedback</a>
</div>

<p class="text-muted">© 2026 Recipe Rush | Made for food lovers</p>

</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>