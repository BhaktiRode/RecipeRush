<?php
$conn = mysqli_connect("sql100.infinityfree.com","if0_41421772","ZhTezeJRMZeRYqb","if0_41421772_reciperush");

$result = mysqli_query($conn,"SELECT * FROM products");
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Recipes</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{ background:#fdf6f0; }

.card{
border-radius:12px;
overflow:hidden;
box-shadow:0 4px 12px rgba(0,0,0,0.1);
}

.card img{
height:200px;
object-fit:cover;
}
</style>
</head>

<body>

<div class="container mt-5">

<h2 class="text-center mb-4">Our Recipes</h2>

<div class="row">

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<div class="col-md-4 mb-4">
<div class="card">

<img src="<?php echo $row['image']; ?>">

<div class="card-body text-center">
<h5><?php echo $row['name']; ?></h5>
<p>₹<?php echo $row['price']; ?></p>

<button class="btn btn-warning">Order Now</button>

</div>

</div>
</div>

<?php } ?>

</div>

</div>

</body>
</html>