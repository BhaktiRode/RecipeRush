<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
); // ✅ FIXED

if(isset($_POST['signup'])){

$name = $_POST['name'];
$mobile = $_POST['mobile'];
$email = $_POST['email'];
$address = $_POST['address'];
$password = $_POST['password'];

$query = "INSERT INTO users (username, email, phone, address, password)
VALUES ('$name','$email','$mobile','$address','$password')";

mysqli_query($conn,$query);

header("Location: user-login.php");
exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>FoodHub Sign Up</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
:root{
--primary-orange:#f2873d;
--bg-color:#f9f1ee;
--card-bg:#ffffff;
--border:#e0e0e0;
}

body{
font-family:'Segoe UI',sans-serif;
background:var(--bg-color);
display:flex;
justify-content:center;
align-items:center;
height:100vh;
margin:0;
}

.signup-card{
background:var(--card-bg);
padding:40px;
border-radius:30px;
box-shadow:0 10px 25px rgba(0,0,0,0.05);
width:400px;
text-align:center;
}

.logo{
display:flex;
justify-content:center;
align-items:center;
gap:8px;
margin-bottom:15px;
}

.logo span{
font-size:26px;
font-weight:bold;
color:#444;
}

h2{
margin-bottom:25px;
color:#444;
}

.input-group{
position:relative;
margin-bottom:15px;
}

.input-group i{
position:absolute;
left:12px;
top:50%;
transform:translateY(-50%);
color:#aaa;
}

.input-group input,
.input-group textarea{
width:100%;
padding:12px 12px 12px 38px; /* removed extra space */
border:1px solid var(--border);
border-radius:10px;
outline:none;
font-size:14px;
box-sizing:border-box;
}

.signup-btn{
width:100%;
padding:13px;
border:none;
border-radius:25px;
background:linear-gradient(to right,#ff5a00,#ff9a52);
color:white;
font-size:16px;
font-weight:bold;
cursor:pointer;
margin-top:10px;
}

.error{
color:red;
font-size:13px;
margin-bottom:10px;
}

.login-text{
margin-top:18px;
font-size:14px;
}

.login-text a{
color:var(--primary-orange);
font-weight:600;
text-decoration:none;
}
</style>
</head>

<body>

<div class="signup-card">

<div class="logo">
<img src="foodlogo.png" width="45">
<span>Recipe<span style="color:orange;">Rush</span></span>
</div>

<h2>Create Account</h2>

<?php if(isset($error)){ ?>
<p class="error"><?php echo $error; ?></p>
<?php } ?>

<form method="POST">

<div class="input-group">
<i class="fa fa-user"></i>
<input type="text" name="name" placeholder="Full Name" required>
</div>

<div class="input-group">
<i class="fa fa-phone"></i>
<input type="tel" name="mobile" placeholder="Mobile Number" required>
</div>

<div class="input-group">
<i class="fa fa-envelope"></i>
<input type="email" name="email" placeholder="Email Address" required>
</div>

<div class="input-group">
<i class="fa fa-map-marker-alt"></i>
<textarea name="address" placeholder="Delivery Address" rows="2" required></textarea>
</div>

<div class="input-group">
<i class="fa fa-lock"></i>
<input type="password" name="password" placeholder="Password" required>
</div>

<div class="input-group">
<i class="fa fa-lock"></i>
<input type="password" placeholder="Confirm Password" required>
</div>

<button type="submit" name="signup" class="signup-btn">Sign Up</button>

</form>

<div class="login-text">
Already have an account? <a href="user-login.php">Login</a>
</div>

</div>

</body>
</html>