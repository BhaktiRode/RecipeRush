<?php
session_start();

/* ✅ TIMEZONE FIX */
date_default_timezone_set('Asia/Kolkata');

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed");
}

if(!isset($_SESSION['user'])){
header("Location: user-login.php");
exit();
}

$user = $_SESSION['user'];

/* FETCH CART */
$cart = mysqli_query($conn,"SELECT * FROM cart WHERE username='$user'");

/* CALCULATE TOTAL */
$total = 0;
while($row = mysqli_fetch_assoc($cart)){
$total += $row['price'] * $row['qty'];
}

/* REFRESH CART AGAIN */
$cart = mysqli_query($conn,"SELECT * FROM cart WHERE username='$user'");

/* PLACE ORDER */
if(isset($_POST['confirm_payment'])){

$payment = $_POST['payment'];

/* ✅ CARD VALIDATION */
if($payment == "Card"){
if(empty($_POST['card']) || empty($_POST['cvv'])){
echo "<script>alert('Please enter card details');</script>";
exit();
}
}

/* ✅ CURRENT DATE */
$date = date("Y-m-d H:i:s");

/* 1. INSERT MAIN ORDER (FIXED) */
mysqli_query($conn,"
INSERT INTO orders (customer, total_amount, payment_method, status, order_date)
VALUES ('$user','$total','$payment','Paid','$date')
");

/* 2. GET ORDER ID */
$order_id = mysqli_insert_id($conn);

/* 3. INSERT ITEMS */
while($row = mysqli_fetch_assoc($cart)){

$name = $row['product_name'];
$price = $row['price'];
$qty = $row['qty'];

mysqli_query($conn,"
INSERT INTO order_items (order_id, product_name, price, qty)
VALUES ('$order_id','$name','$price','$qty')
");

}

/* 4. CLEAR CART */
mysqli_query($conn,"DELETE FROM cart WHERE username='$user'");

/* 5. REDIRECT */
echo "<script>
alert('Payment Successful!');
window.location='order-success.php?id=$order_id';
</script>";
exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Payment</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
background:#f3f3f3;
font-family:'Segoe UI', sans-serif;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.payment-container{
background:#ffffff;
padding:40px;
border-radius:25px;
width:500px;
box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

.title{
text-align:center;
font-size:28px;
margin-bottom:20px;
}

.total-box{
background:#fff3e8;
padding:10px;
border-radius:10px;
text-align:center;
font-weight:bold;
margin-bottom:20px;
}

.qr-box{
text-align:center;
margin:20px 0;
}

.qr-box img{
width:180px;
}

.order-btn{
background:linear-gradient(90deg,#ff5a00,#ff9a4d);
border:none;
padding:12px;
border-radius:30px;
width:100%;
color:white;
font-size:16px;
margin-top:20px;
}
</style>

</head>

<body>

<div class="payment-container">

<div class="title">Select Payment Method</div>

<div class="total-box">
Total Amount: ₹<?php echo $total; ?>
</div>

<form method="POST">

<div class="form-check">
<input class="form-check-input" type="radio" name="payment" value="UPI" required>
<label class="form-check-label">UPI (Google Pay / PhonePe)</label>
</div>

<div class="qr-box">
<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=paytm123@upi">
<p class="text-muted">Scan to Pay</p>
</div>

<div class="form-check">
<input class="form-check-input" type="radio" name="payment" value="Card">
<label class="form-check-label">Credit / Debit Card</label>
</div>

<div id="card-box" style="display:none; margin-top:15px;">

<div class="mb-2">
<label>Card Holder Name</label>
<input type="text" name="holder" class="form-control">
</div>

<div class="mb-2">
<label>Card Number</label>
<input type="text" name="card" class="form-control" maxlength="16">
</div>

<div class="row">
<div class="col-md-6 mb-2">
<label>Expiry</label>
<input type="text" name="expiry" class="form-control" placeholder="MM/YY">
</div>

<div class="col-md-6 mb-2">
<label>CVV</label>
<input type="password" name="cvv" class="form-control" maxlength="3">
</div>
</div>

</div>

<div class="form-check">
<input class="form-check-input" type="radio" name="payment" value="COD">
<label class="form-check-label">Cash on Delivery</label>
</div>

<button type="submit" name="confirm_payment" class="order-btn">
Confirm Payment
</button>

</form>

</div>

<script>
const options = document.querySelectorAll("input[name='payment']");
const cardBox = document.getElementById("card-box");

options.forEach(opt => {
opt.addEventListener("change", function(){
if(this.value === "Card"){
cardBox.style.display = "block";
}else{
cardBox.style.display = "none";
}
});
});
</script>

</body>
</html>