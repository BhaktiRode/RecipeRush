# RecipeRush

**Online Recipe and Ingredients Ordering System**

RecipeRush is a B.Sc. Computer Science final-year project that combines recipe discovery with ingredient ordering. Users can browse recipes, search dishes, view recipe details, manage a shopping cart, and order ingredients. An admin panel provides management of products, recipes, users, orders, and feedback.

## Technologies Used

- HTML5
- CSS3
- JavaScript
- Bootstrap
- PHP
- MySQL
- Chart.js
- Font Awesome

## Main Features

### User Side
- Recipe browsing by category
- Breakfast, lunch, dinner, and dessert sections
- Recipe search
- Recipe details
- Ingredient/product browsing
- Shopping cart
- User login and signup
- Checkout and payment flow
- Feedback

### Admin Side
- Admin authentication
- Dashboard
- User management
- Product management
- Order management
- Feedback management
- Recipe management
- Views, revenue, and order statistics

## Project Structure

The repository contains the PHP application files, CSS/JavaScript assets, images, and administrative modules.

## How to Run Locally

1. Install XAMPP.
2. Start **Apache** and **MySQL**.
3. Copy the project folder into:
   `C:\xampp\htdocs\`
4. Import the project's MySQL database using phpMyAdmin.
5. Update the database connection settings in the project if required.
6. Open the project in a browser, for example:
   `http://localhost/RecipeRush/`

## Academic Project

**Degree:** B.Sc. Computer Science  
**Project:** RecipeRush — Online Recipe and Ingredients Ordering System

> Note: Database credentials and other private configuration values should not be committed to a public repository.
