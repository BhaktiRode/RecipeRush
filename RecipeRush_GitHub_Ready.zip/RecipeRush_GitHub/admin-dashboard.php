<?php
error_reporting(0);
session_start();

if(!isset($_SESSION['admin'])){
    header("Location: admin-login.html");
    exit();
}
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Panel</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet">

<style>
*{ font-family:'Playfair Display',serif; }

body{
    background:#fdf6f0;
}

/* NAVBAR */
.navbar{
    background:#f8e8d8 !important;
    border-radius:0.5cm;
}

/* HERO */
.admin-hero{
    background:linear-gradient(rgba(253,246,240,0.5),rgba(253,246,240,0.3)), 
    url("image1.png") center/cover no-repeat;
    height:400px;
    display:flex;
    align-items:center;
    justify-content:center;
    text-align:center;
}

/* SECTION */
.section{
    margin-top:60px;
}

/* CARD */
.admin-card{
    border-radius:15px;
    background:#fff3e6;
    box-shadow:0 6px 18px rgba(0,0,0,0.08);
    padding:25px;
    text-align:center;
    height:100%;
    transition:0.3s;
}

.admin-card:hover{
    transform:translateY(-5px);
}

/* ICON */
.admin-card i{
    font-size:32px;
    color:#fb6b2a;
    margin-bottom:10px;
}

/* BUTTON */
.btn-theme{
    background:#fb6b2a;
    color:white;
    border:none;
    border-radius:25px;
    padding:6px 18px;
}

.btn-theme:hover{
    background:#e55b1f;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg shadow-sm">
<div class="container-fluid px-3">

<a class="navbar-brand d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
Recipe<span style="color:orange;">Rush</span>
</a>

<div class="ms-auto">
<a href="index.php" class="nav-link d-inline">Home</a>
<a href="logout.php" class="btn btn-warning ms-2">Logout</a>
</div>

</div>
</nav>

<!-- HERO -->
<section class="admin-hero">
<div>
<h1>Admin Control Panel</h1>
<p>Manage your recipes, users and orders easily</p>
</div>
</section>

<!-- ACTION SECTION -->
<section class="container section text-center">

<h2 class="fw-bold mb-5">Manage Platform</h2>

<div class="row g-4 justify-content-center">

<!-- RECIPES -->
<div class="col-md-3">
<div class="admin-card">
<i class="fa fa-utensils"></i>
<h5>Manage Recipes</h5>
<a href="admin-products.php" class="btn btn-theme mt-2">Go</a>
</div>
</div>

<!-- ORDERS -->
<div class="col-md-3">
<div class="admin-card">
<i class="fa fa-box"></i>
<h5>Orders</h5>
<a href="admin-orders.php" class="btn btn-theme mt-2">View</a>
</div>
</div>

<!-- USERS -->
<div class="col-md-3">
<div class="admin-card">
<i class="fa fa-users"></i>
<h5>Users</h5>
<a href="admin-users.php" class="btn btn-theme mt-2">View</a>
</div>
</div>

<!-- FEEDBACK -->
<div class="col-md-3">
<div class="admin-card">
<i class="fa fa-comments"></i>
<h5>Feedback</h5>
<a href="admin-feedback.php" class="btn btn-theme mt-2">View</a>
</div>
</div>

</div>

</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>