<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(isset($_POST['product']) && isset($_SESSION['user'])){

    $user = $_SESSION['user'];
    $product = $_POST['product'];

    // check if item already exists
    $check = mysqli_query($conn,"SELECT * FROM cart WHERE username='$user' AND product_name='$product'");

    if(mysqli_num_rows($check) > 0){
        // increase quantity
        mysqli_query($conn,"UPDATE cart SET qty = qty + 1 WHERE username='$user' AND product_name='$product'");
    } else {
        // add new item (use your real price if available)
        mysqli_query($conn,"INSERT INTO cart (username, product_name, qty, price) VALUES ('$user','$product',1,50)");
    }

    header("Location: " . $_SERVER['HTTP_REFERER']);
    exit();
}
?>