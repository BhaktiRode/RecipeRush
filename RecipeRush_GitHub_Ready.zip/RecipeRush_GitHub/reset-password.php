<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

$msg = "";

/* ✅ USE SESSION (NOT URL) */
if(!isset($_SESSION['reset_email'])){
header("Location: forgot-password.php");
exit();
}

$email = $_SESSION['reset_email'];

if(isset($_POST['update'])){

$new = mysqli_real_escape_string($conn, $_POST['new_password']);
$confirm = mysqli_real_escape_string($conn, $_POST['confirm_password']);

if($new !== $confirm){
$msg = "Passwords do not match!";
}else{

mysqli_query($conn,"
UPDATE users SET password='$new' 
WHERE email='$email'
");

/* ✅ CLEAR SESSION AFTER RESET */
unset($_SESSION['reset_email']);

echo "<script>
alert('Password updated successfully!');
window.location='user-login.php';
</script>";
exit();
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Reset Password</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
body{
font-family:'Segoe UI';
background:#f9f1ee;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
margin:0;
}

.card{
background:#fff;
padding:50px 30px;
border-radius:25px;
width:350px;
text-align:center;
box-shadow:0 10px 30px rgba(0,0,0,0.05);
}

h2{
margin-bottom:10px;
}

p{
color:#777;
margin-bottom:20px;
}

.input-group{
position:relative;
margin-bottom:15px;
}

.input-group i{
position:absolute;
left:12px;
top:50%;
transform:translateY(-50%);
color:#999;
}

.input-group input{
width:100%;
padding:12px 12px 12px 35px;
border-radius:10px;
border:1px solid #ddd;
}

button{
background:linear-gradient(#f75600,#ff9a52);
color:white;
border:none;
padding:12px;
width:100%;
border-radius:20px;
cursor:pointer;
}

button:hover{
opacity:0.9;
}

.msg{
color:red;
margin-bottom:10px;
}

.back{
display:block;
margin-top:10px;
font-size:13px;
color:#666;
text-decoration:none;
}
</style>
</head>

<body>

<div class="card">

<h2>Reset Password</h2>

<p>Enter your new password</p>

<form method="POST">

<div class="input-group">
<i class="fa fa-lock"></i>
<input type="password" name="new_password" placeholder="New Password" required>
</div>

<div class="input-group">
<i class="fa fa-lock"></i>
<input type="password" name="confirm_password" placeholder="Confirm Password" required>
</div>

<p class="msg"><?php echo $msg; ?></p>

<button name="update">Update Password</button>

</form>

<a href="user-login.php" class="back">Back to Login</a>

</div>

</body>
</html>