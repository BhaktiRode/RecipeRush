<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

$msg = "";

if(isset($_POST['reset'])){

$email = mysqli_real_escape_string($conn, $_POST['email']);

$res = mysqli_query($conn,"SELECT * FROM users WHERE email='$email'");

if(mysqli_num_rows($res) > 0){

// ✅ STORE IN SESSION (BETTER THAN URL)
$_SESSION['reset_email'] = $email;

// ✅ PROPER REDIRECT
header("Location: reset-password.php");
exit();

}else{
$msg = "Email not found!";
}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Forgot Password</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

<style>
:root {
--primary-orange: #f2873d;
--bg-color: #f9f1ee;
--card-bg: #ffffff;
--text-gray: #888888;
--border-color: #e8e8e8;
}

body {
font-family: 'Segoe UI';
background-color: var(--bg-color);
display: flex;
justify-content: center;
align-items: center;
height: 100vh;
margin: 0;
}

.forgot-card {
background-color: var(--card-bg);
padding: 65px 35px;
border-radius: 30px;
box-shadow: 0 10px 30px rgba(0, 0, 0, 0.04);
width: 100%;
max-width: 380px;
text-align: center;
}

h2 {
color: #4a4a4a;
font-family: 'Georgia', serif;
font-size: 24px;
margin-bottom: 15px;
}

.description {
color: var(--text-gray);
font-size: 14px;
margin-bottom: 25px;
}

.input-group {
position: relative;
margin-bottom: 20px;
}

.input-group i {
position: absolute;
left: 15px;
top: 50%;
transform: translateY(-50%);
color: #b0b0b0;
}

.input-group input {
width: 100%;
padding: 14px 15px 14px 45px;
border: 1px solid var(--border-color);
border-radius: 15px;
outline: none;
}

.reset-btn {
width: 100%;
padding: 14px;
background: linear-gradient(to right, #f75600, #ff9a52);
color: white;
border: none;
border-radius: 25px;
font-size: 16px;
font-weight: 600;
cursor: pointer;
margin-bottom: 15px;
}

.msg{
color:red;
margin-bottom:10px;
}

.back-link {
color: var(--primary-orange);
text-decoration: none;
font-size: 14px;
font-weight: 600;
}
</style>
</head>

<body>

<div class="forgot-card">

<h2>Forgot Password</h2>

<p class="description">
Enter your registered email to reset password
</p>

<form method="POST">

<div class="input-group">
<i class="fa fa-envelope"></i>
<input type="email" name="email" placeholder="Email Address" required>
</div>

<p class="msg"><?php echo $msg; ?></p>

<button type="submit" name="reset" class="reset-btn">
Continue
</button>

</form>

<a href="user-login.php" class="back-link">Back to Login</a>

</div>

</body>
</html>