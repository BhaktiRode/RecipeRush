<?php
$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

$q = $_GET['q'];

$result = mysqli_query($conn,"
SELECT * FROM products 
WHERE name LIKE '%$q%'
");

$count = mysqli_num_rows($result);
?>

<!DOCTYPE html>
<html>
<head>
<title>Search</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>

body{
    background:#fdf5e6;
    font-family:'Segoe UI', sans-serif;
}

/* Heading */
h3{
    margin-bottom: 40px;
    color: #3e2723;
}

/* CENTER */
.row{
    justify-content: center;
}

/* CARD */
.card{
    border:none;
    border-radius:20px;
    overflow:hidden;
    box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    transition:0.3s;
    max-width: 650px;
    width: 100%;
}

.card:hover{
    transform: translateY(-6px);
    box-shadow: 0 15px 35px rgba(0,0,0,0.2);
}

/* IMAGE */
.card img{
    height:320px; /* 🔥 balanced */
    width:100%;
    object-fit:cover;
}

/* BODY (FIXED WHITE SPACE) */
.card-body{
    padding:15px 20px; /* reduced */
    text-align:center;
}

/* TITLE */
.card h4{
    font-size:18px;
    margin-bottom:10px;
}

/* BUTTON */
.btn-theme{
    background:#ff7a00;
    color:white;
    border:none;
    border-radius:25px;
    padding:8px 20px;
    font-size:14px;
    transition:0.3s;
}

.btn-theme:hover{
    background:#e66a00;
    color:white;
}

/* NO RESULT */
.no-result{
    text-align:center;
    font-size:18px;
    color:#777;
}

</style>

</head>

<body>

<div class="container mt-5">

<h3>Search Results for "<?php echo $q; ?>"</h3>

<div class="row">

<?php
if($count > 0){

while($row = mysqli_fetch_assoc($result)){
?>

<div class="col-md-8 d-flex justify-content-center">

    <div class="card mb-4">

        <img src="<?php echo $row['image']; ?>">

        <div class="card-body">
            <h4><?php echo $row['name']; ?></h4>

            <a href="recipe.php?id=<?php echo $row['id']; ?>" class="btn btn-theme">
                View Recipe
            </a>
        </div>

    </div>

</div>

<?php
}
} else {
?>

<p class="no-result">No results found</p>

<?php } ?>

</div>

</div>

</body>
</html>