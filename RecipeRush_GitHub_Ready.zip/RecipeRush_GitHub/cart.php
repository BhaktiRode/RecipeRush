<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Database connection failed");
}

// check login
if(!isset($_SESSION['user'])){
header("Location: user-login.php");
exit();
}

$user = mysqli_real_escape_string($conn, $_SESSION['user']);

// fetch cart data
$result = mysqli_query($conn,"SELECT * FROM cart WHERE username='$user'");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Recipe Rush - Cart</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Crimson+Text:wght@400;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>
:root{
--primary-orange:#f2873d;
--bg-color:#f9f1ee;
}

body{
font-family:'Crimson Text',serif;
background-color:var(--bg-color);
}

.cart-container{
background:#fff;
border-radius:35px;
max-width:650px;
margin:2rem auto;
padding:40px;
box-shadow:0 4px 20px rgba(0,0,0,0.04);
}

.item-row{
border-bottom:1px dashed #ddd;
padding:15px 0;
}

.navbar{
background:#fff;
box-shadow:0 2px 6px rgba(0,0,0,0.05);
}

.navbar-brand{
font-weight:bold;
font-size:22px;
}

.price-col{
font-weight:700;
font-size:1.1rem;
min-width:120px;
text-align:right;
}

.btn-orange{
background:linear-gradient(to bottom,#f37d21,#e65c00);
color:white;
border-radius:50px;
border:none;
font-weight:600;
}

.qty-btn{
padding:2px 10px;
border-radius:5px;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg bg-light shadow-sm">
<div class="container-fluid px-3">

<a class="navbar-brand fw-bold d-flex align-items-center" href="index.php">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span>Recipe<span style="color:orange;">Rush</span></span>
</a>

</div>
</nav>

<!-- TITLE -->
<div class="text-center my-4">
<h1 class="fw-bold">Shopping Cart 🛒</h1>
<a href="index.php" class="btn btn-secondary mt-2">← Continue Shopping</a>
</div>

<!-- CART -->
<div class="container pb-5">

<div class="cart-container">

<h2 class="mb-4">Your Items</h2>

<?php
$total = 0;

if(mysqli_num_rows($result) == 0){
?>

<div class="text-center py-4">
<h5>Your cart is empty</h5>
<p class="text-muted">Start adding items!</p>
</div>

<?php
}else{

while($row = mysqli_fetch_assoc($result)){

$itemTotal = $row['price'] * $row['qty'];
$total += $itemTotal;
?>

<div class="item-row d-flex justify-content-between align-items-center">

<!-- ITEM NAME -->
<div>
<span class="fs-5 fw-semibold">
<?php echo $row['product_name']; ?>
</span>
</div>

<!-- QTY CONTROLS -->
<div class="d-flex align-items-center gap-2">

<a href="update-cart.php?id=<?php echo $row['id']; ?>&action=dec" class="btn btn-sm btn-secondary qty-btn">-</a>

<span>x<?php echo $row['qty']; ?></span>

<a href="update-cart.php?id=<?php echo $row['id']; ?>&action=inc" class="btn btn-sm btn-secondary qty-btn">+</a>

</div>

<!-- PRICE + DELETE -->
<div class="d-flex align-items-center gap-3">

<div class="price-col">
₹ <?php echo $itemTotal; ?>
</div>

<a href="remove.php?id=<?php echo $row['id']; ?>" class="text-danger">
<i class="fa fa-trash"></i>
</a>

</div>

</div>

<?php
}
}
?>

<hr>

<div class="d-flex justify-content-between align-items-center mb-4">
<span class="fs-4 opacity-75">Estimated Total:</span>
<span class="fs-2 fw-bold">₹ <?php echo $total; ?></span>
</div>

<a href="checkout.php" class="btn btn-orange w-100 py-3 fs-5">
🛒 Proceed to Checkout
</a>

</div>

</div>

</body>
</html>