<?php
$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(isset($_POST['id'])){
    $id = $_POST['id'];

    /* 🔥 DELETE INGREDIENTS FIRST */
    mysqli_query($conn,"DELETE FROM ingredients WHERE product_id=$id");

    /* 🔥 THEN DELETE PRODUCT */
    mysqli_query($conn,"DELETE FROM products WHERE id=$id");
}

/* ✅ REDIRECT BACK */
header("Location: admin-products.php");
exit();
?>