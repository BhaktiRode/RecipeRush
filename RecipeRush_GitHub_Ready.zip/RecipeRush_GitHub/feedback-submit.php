<?php
session_start();

/* DEBUG (remove later) */
error_reporting(E_ALL);
ini_set('display_errors', 1);

/* TIMEZONE */
date_default_timezone_set('Asia/Kolkata');

/* DB */
$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed: " . mysqli_connect_error());
}

/* DATA */
$username = isset($_SESSION['user']) ? $_SESSION['user'] : "Guest";
$message = mysqli_real_escape_string($conn, $_POST['message']);

/* DATE */
$date = date("Y-m-d H:i:s");

/* ✅ FIXED COLUMN NAME */
$query = "
INSERT INTO feedback (username, message, created_at)
VALUES ('$username','$message','$date')
";

if(!mysqli_query($conn,$query)){
die("Error: " . mysqli_error($conn));
}

/* REDIRECT */
header("Location: index.php");
exit();
?>