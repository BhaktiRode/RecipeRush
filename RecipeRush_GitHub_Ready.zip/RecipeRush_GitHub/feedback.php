<?php
$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

$result = mysqli_query($conn,"SELECT * FROM feedback ORDER BY id DESC");
?>

<!DOCTYPE html>
<html>
<head>
<title>Feedback</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600&family=Poppins:wght@300;400;500&display=swap');

body{
    margin:0;
    font-family:'Poppins', sans-serif;
}

/* HERO */
.hero{
    height:100vh;
    display:flex;
    flex-direction:column;
    justify-content:flex-start;
    padding-left:12%;
    padding-top:60px;

    background: linear-gradient(to right, rgba(255,255,255,0.6) 30%, transparent),
    url('welcome.png');
    background-size:cover;
    background-position:center;
}

/* TITLE */
.title{
    font-family:'Playfair Display', serif;
    font-size:60px;
    margin-bottom:15px;
}

.title span{
    color:#ff7a00;
}

/* TYPEWRITER */
.typing{
    font-size:26px;
    color:#5d4037;
    font-weight:500;
    border-right:3px solid #ff7a00;
    white-space:nowrap;
    overflow:hidden;
    width:0;
    animation: typing 3s steps(40,end) forwards, blink .7s infinite;
    margin-bottom:40px;
}

@keyframes typing{
    from{width:0}
    to{width:100%}
}

@keyframes blink{
    50%{border-color:transparent}
}

/* FEEDBACK BOX */
.feedback-box{
    width:600px;
    max-width:90%;
    height:55vh;
    overflow:hidden;
}

/* SCROLL */
.feedback-list{
    animation: scrollUp 20s linear infinite;
}

@keyframes scrollUp{
    0%{transform:translateY(0)}
    100%{transform:translateY(-100%)}
}

/* GLASS CARD */
.card{
    background: rgba(255,255,255,0.35);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);

    border-radius:20px;
    padding:20px;
    margin-bottom:20px;

    border:1px solid rgba(255,255,255,0.3);
    box-shadow:0 8px 25px rgba(0,0,0,0.08);
    transition:0.3s ease;
}

.card:hover{
    transform:translateY(-5px);
    box-shadow:0 12px 30px rgba(0,0,0,0.15);
}

/* TEXT */
.username{
    font-weight:bold;
    color:#ff7a00;
}

.message{
    margin:6px 0;
    color:#3e2723;
}

.time{
    font-size:12px;
    color:gray;
}
</style>

</head>

<body>

<div class="hero">

<!-- TITLE -->
<div class="title">
    User <span>Feedback</span>
</div>

<!-- TYPE TEXT -->
<div class="typing">
    See what our users are saying...
</div>

<!-- FEEDBACK CARDS -->
<div class="feedback-box">
<div class="feedback-list">

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<div class="card">
    <div class="username"><?php echo $row['username']; ?></div>
    <div class="message"><?php echo $row['message']; ?></div>
    <div class="time"><?php echo $row['created_at']; ?></div>
</div>

<?php } ?>

</div>
</div>

</div>

</body>
</html>