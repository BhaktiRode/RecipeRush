<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed");
}

// LOGIN CHECK
if(!isset($_SESSION['user'])){
header("Location: user-login.php");
exit();
}

$user = mysqli_real_escape_string($conn, $_SESSION['user']);

/* FETCH CART INTO ARRAY */
$cart_items = [];
$cart_query = mysqli_query($conn,"SELECT * FROM cart WHERE username='$user'");

while($row = mysqli_fetch_assoc($cart_query)){
$cart_items[] = $row;
}

/* FETCH USER DATA */
$userData = mysqli_fetch_assoc(
mysqli_query($conn,"SELECT * FROM users WHERE username='$user'")
);

/* CALCULATE TOTAL */
$total = 0;
$count = count($cart_items);

foreach($cart_items as $item){
$total += $item['price'] * $item['qty'];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Checkout</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{
background:#f3f3f3;
font-family:'Segoe UI', sans-serif;
display:flex;
justify-content:center;
align-items:center;
min-height:100vh;
}

.checkout-container{
background:#ffffff;
padding:40px;
border-radius:25px;
width:700px;
box-shadow:0 10px 30px rgba(0,0,0,0.1);
}

.logo{
text-align:center;
font-size:28px;
margin-bottom:20px;
}

.title{
text-align:center;
font-size:28px;
margin-bottom:25px;
}

.order-summary{
background:#fff7f0;
padding:15px;
border-radius:15px;
margin-bottom:20px;
}

.pay-btn{
background:linear-gradient(90deg,#ff5a00,#ff9a4d);
border:none;
padding:12px;
border-radius:30px;
width:100%;
color:white;
font-size:16px;
}

.empty{
text-align:center;
color:#777;
}
</style>
</head>

<body>

<div class="checkout-container">

<div class="logo">
Recipe <span style="color:orange;">Rush</span>
</div>

<div class="title">Checkout</div>

<!-- EMPTY CART -->
<?php if($count == 0){ ?>

<div class="empty">
<h5>Your cart is empty 😢</h5>
<a href="index.php" class="btn btn-secondary mt-3">Go Shopping</a>
</div>

<?php } else { ?>

<!-- ORDER SUMMARY -->
<div class="order-summary">
<h5>Order Summary</h5>

<p>Items: <?php echo $count; ?></p>
<p>Total: ₹<?php echo $total; ?></p>

</div>

<!-- ✅ SINGLE FORM -->
<form method="POST" action="payment.php">

<div class="row">

<div class="col-md-6 mb-3">
<label>Full Name</label>
<input type="text" name="name" class="form-control"
value="<?php echo $userData['username']; ?>" required>
</div>

<div class="col-md-6 mb-3">
<label>Phone</label>
<input type="text" name="phone" class="form-control"
value="<?php echo $userData['phone']; ?>" required>
</div>

<div class="col-12 mb-3">
<label>Address</label>
<input type="text" name="address" class="form-control"
value="<?php echo $userData['address']; ?>" required>
</div>

</div>

<input type="hidden" name="total" value="<?php echo $total; ?>">

<button type="submit" class="pay-btn">
Proceed to Payment
</button>

</form>

<?php } ?>

</div>

</body>
</html>