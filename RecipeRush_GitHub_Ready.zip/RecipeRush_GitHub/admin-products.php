<?php
session_start();

if(!isset($_SESSION['admin'])){
header("Location: admin-login.html");
exit();
}

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

// ADD RECIPE
if(isset($_POST['add'])){
$name = $_POST['name'];
$image = $_POST['image'];
$category = $_POST['category'];
$time = $_POST['time'];

/* ✅ NEW FIELDS */
$description = $_POST['description'];
$instructions = $_POST['instructions'];
$video = $_POST['video'];

mysqli_query($conn,"
INSERT INTO products (name, image, category, time, description, instructions, video)
VALUES ('$name','$image','$category','$time','$description','$instructions','$video')
");

/* 🔥 NEW PART START (INGREDIENTS SAVE) */
$product_id = mysqli_insert_id($conn);

if(isset($_POST['ingredient_name'])){
foreach($_POST['ingredient_name'] as $index => $ing_name){

$price = $_POST['ingredient_price'][$index];

if(!empty($ing_name)){
mysqli_query($conn,"
INSERT INTO ingredients (product_id, name, price)
VALUES ('$product_id','$ing_name','$price')
");
}
}
}
/* 🔥 NEW PART END */
}

// FETCH PRODUCTS
$result = mysqli_query($conn,"SELECT * FROM products");
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Manage Recipes</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body{ background:#fdf6f0; }

.container-box{
background:#f8e8d8;
padding:20px;
border-radius:15px;
margin-top:30px;
}

.card img{
height:200px;
object-fit:cover;
}
</style>
</head>

<body>

<div class="container mt-4">

<h2 class="text-center mb-4">Manage Recipes</h2>

<!-- ADD FORM -->
<div class="container-box">

<h4>Add New Recipe</h4>

<form method="POST">

<div class="row">

<div class="col-md-3">
<input type="text" name="name" class="form-control" placeholder="Recipe Name" required>
</div>

<div class="col-md-3">
<input type="text" name="category" class="form-control" placeholder="Category" required>
</div>

<div class="col-md-3">
<input type="text" name="time" class="form-control" placeholder="Time (e.g. 20 mins)" required>
</div>

<div class="col-md-3">
<input type="text" name="image" class="form-control" placeholder="Image URL" required>
</div>

</div>

<!-- NEW INPUTS -->
<div class="mt-3">
<textarea name="description" class="form-control mb-2" placeholder="Description"></textarea>

<textarea name="instructions" class="form-control mb-2" placeholder="Instructions"></textarea>

<input type="text" name="video" class="form-control" placeholder="YouTube Embed Link">
</div>

<!-- 🔥 INGREDIENTS INPUT -->
<div class="mt-3">

<h5>Ingredients</h5>

<div id="ingredients-box">

<div class="row mb-2">
<div class="col-md-6">
<input type="text" name="ingredient_name[]" class="form-control" placeholder="Ingredient Name">
</div>

<div class="col-md-3">
<input type="number" name="ingredient_price[]" class="form-control" placeholder="Price">
</div>
</div>

</div>

<button type="button" class="btn btn-sm btn-secondary" onclick="addIngredient()">
+ Add More
</button>

</div>

<button name="add" class="btn btn-warning mt-3">Add Recipe</button>

</form>

</div>

<!-- SHOW RECIPES -->
<div class="row mt-4">

<?php while($row = mysqli_fetch_assoc($result)){ ?>

<div class="col-md-4 mb-4">
<div class="card shadow-sm">

<img src="<?php echo $row['image']; ?>" class="card-img-top">

<div class="card-body text-center">

<h5><?php echo $row['name']; ?></h5>

<p><?php echo $row['category']; ?> | <?php echo $row['time']; ?></p>

<form method="POST" action="delete.php" style="display:inline;">
<input type="hidden" name="id" value="<?php echo $row['id']; ?>">
<button type="submit" class="btn btn-danger btn-sm mt-2"
onclick="return confirm('Delete this recipe?')">
Delete
</button>
</form>

</div>

</div>
</div>

<?php } ?>

</div>

</div>

<!-- 🔥 JS FOR ADDING INGREDIENTS -->
<script>
function addIngredient(){
let box = document.getElementById("ingredients-box");

box.innerHTML += `
<div class="row mb-2">
<div class="col-md-6">
<input type="text" name="ingredient_name[]" class="form-control" placeholder="Ingredient Name">
</div>

<div class="col-md-3">
<input type="number" name="ingredient_price[]" class="form-control" placeholder="Price">
</div>
</div>`;
}
</script>

</body>
</html>