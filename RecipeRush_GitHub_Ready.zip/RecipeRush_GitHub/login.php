<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed");
}

if(isset($_POST['login'])){

$email = $_POST['email'];
$password = $_POST['password'];

$result = mysqli_query($conn,"
SELECT * FROM users 
WHERE email='$email' AND password='$password'
");

if(mysqli_num_rows($result) > 0){

$_SESSION['user'] = $email;

header("Location: index.php");
exit();

}else{
$error = "Invalid Email or Password";
}
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Recipe Rush Login</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">

<style>

body{
margin:0;
font-family:'Poppins',sans-serif;
background:#f5ebe7;
display:flex;
justify-content:center;
align-items:center;
height:100vh;
}

.container{
background:#fff;
padding:40px;
border-radius:25px;
width:350px;
text-align:center;
box-shadow:0 10px 30px rgba(0,0,0,0.05);
}

.logo{
font-size:22px;
font-weight:600;
margin-bottom:20px;
}

.logo span{
color:#ff6b00;
}

h2{
margin-bottom:20px;
}

.input-box{
width:100%;
padding:12px;
margin-bottom:15px;
border-radius:15px;
border:1px solid #ddd;
outline:none;
}

.login-btn{
width:100%;
padding:12px;
border:none;
border-radius:25px;
background:linear-gradient(90deg,#ff5a00,#ff9a4d);
color:white;
font-weight:600;
cursor:pointer;
}

.login-btn:hover{
opacity:0.9;
}

.forgot{
display:block;
margin-top:10px;
font-size:13px;
color:#666;
text-decoration:none;
}

.signup{
margin-top:15px;
font-size:14px;
}

.signup a{
color:#ff6b00;
text-decoration:none;
}

.error{
color:red;
margin-top:10px;
}

</style>
</head>

<body>

<div class="container">

<div class="logo">
Recipe <span>Rush</span>
</div>

<h2>Welcome Back!</h2>

<form method="POST">

<input type="email" name="email" placeholder="Email Address" class="input-box" required>

<input type="password" name="password" placeholder="Password" class="input-box" required>

<button type="submit" name="login" class="login-btn">Login</button>

<!-- ✅ FORGOT PASSWORD -->
<a href="forgot-password.php" class="forgot">
Forgot Password?
</a>

</form>

<?php if(isset($error)){ ?>
<p class="error"><?php echo $error; ?></p>
<?php } ?>

<div class="signup">
Don't have an account? <a href="signup.php">Sign Up</a>
</div>

</div>

</body>
</html>