<?php
session_start();

$conn = mysqli_connect(
"sql100.infinityfree.com",
"if0_41421772",
"ZhTezeJRMZeRYqb",
"if0_41421772_reciperush"
);

if(!$conn){
die("Connection failed");
}

$error = "";

if(isset($_POST['login'])){

$email = mysqli_real_escape_string($conn, $_POST['email']);
$password = mysqli_real_escape_string($conn, $_POST['password']);

$result = mysqli_query($conn,"
SELECT * FROM users 
WHERE email='$email' AND password='$password'
");

if(mysqli_num_rows($result) > 0){

$userData = mysqli_fetch_assoc($result);
$_SESSION['user'] = $userData['username'];

header("Location: index.php");
exit();

}else{
$error = "Invalid Email or Password";
}

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Recipe Rush Login</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<style>

/* FIX OVERFLOW */
*{
    box-sizing: border-box;
    margin:0;
    padding:0;
}

/* LIGHT BACKGROUND */
body{
    font-family:'Segoe UI', sans-serif;
    background:#f5ebe7;
    display:flex;
    justify-content:center;
    align-items:center;
    height:100vh;
}

/* CARD */
.container{
    background:#ffffff;
    padding:40px;
    border-radius:25px;
    width:350px;
    max-width:90%;
    text-align:center;
    box-shadow:0 10px 30px rgba(0,0,0,0.08);
    animation: fadeIn 0.6s ease;
}

/* ANIMATION */
@keyframes fadeIn{
    from{
        opacity:0;
        transform: translateY(20px);
    }
    to{
        opacity:1;
        transform: translateY(0);
    }
}

.logo{
    font-size:22px;
    font-weight:600;
    margin-bottom:15px;
}

.logo span{
    color:#ff6b00;
}

h2{
    margin-bottom:25px;
}

/* INPUT GROUP */
.input-group{
    position:relative;
    margin-bottom:15px;
    width:100%;
}

.input-group i{
    position:absolute;
    left:15px;
    top:50%;
    transform:translateY(-50%);
    color:#999;
}

/* EYE ICON */
.toggle-pass{
    position:absolute;
    right:15px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    color:#999;
}

/* INPUT */
.input-group input{
    width:100%;
    padding:12px 40px;
    border-radius:15px;
    border:1px solid #ddd;
    outline:none;
    display:block;
}

/* BUTTON */
.login-btn{
    width:100%;
    padding:12px;
    border:none;
    border-radius:25px;
    background:linear-gradient(90deg,#ff5a00,#ff9a4d);
    color:white;
    font-weight:600;
    cursor:pointer;
    margin-top:10px;
    transition:0.3s;
}

.login-btn:hover{
    opacity:0.9;
}

/* LINKS */
.forgot{
    display:block;
    margin-top:12px;
    font-size:13px;
    color:#666;
    text-decoration:none;
}

.signup{
    margin-top:15px;
    font-size:14px;
}

.signup a{
    color:#ff6b00;
    text-decoration:none;
}

/* ERROR */
.error{
    color:red;
    margin-top:10px;
}

</style>
</head>

<body>

<div class="container">

<div class="logo">
<i class="fa fa-utensils"></i>
Recipe <span>Rush</span>
</div>

<h2>Welcome Back!</h2>

<form method="POST">

<div class="input-group">
<i class="fa fa-envelope"></i>
<input type="email" name="email" placeholder="Email Address" required>
</div>

<div class="input-group">
<i class="fa fa-lock"></i>
<input type="password" name="password" id="password" placeholder="Password" required>
<i class="fa fa-eye toggle-pass" onclick="togglePassword()"></i>
</div>

<button type="submit" name="login" class="login-btn">Login</button>

<a href="forgot-password.php" class="forgot">
Forgot Password?
</a>

</form>

<?php if($error != ""){ ?>
<p class="error"><?php echo $error; ?></p>
<?php } ?>

<div class="signup">
Don't have an account? <a href="signup.php">Sign Up</a>
</div>

</div>

<script>
function togglePassword(){
    var pass = document.getElementById("password");
    if(pass.type === "password"){
        pass.type = "text";
    } else {
        pass.type = "password";
    }
}
</script>

</body>
</html>