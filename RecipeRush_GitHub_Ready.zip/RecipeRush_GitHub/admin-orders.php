<?php
error_reporting(0);
session_start();

if(!isset($_SESSION['admin'])){
    header("Location: admin-login.html");
    exit();
}

$conn = mysqli_connect("sql100.infinityfree.com","if0_41421772","ZhTezeJRMZeRYqb","if0_41421772_reciperush");

// DELETE ORDER (also delete items)
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    mysqli_query($conn,"DELETE FROM order_items WHERE order_id=$id");
    mysqli_query($conn,"DELETE FROM orders WHERE id=$id");
}

// TOGGLE STATUS
if(isset($_GET['toggle'])){
    $id = $_GET['toggle'];

    $res = mysqli_query($conn,"SELECT status FROM orders WHERE id=$id");
    $row = mysqli_fetch_assoc($res);

    $newStatus = ($row['status']=="Pending") ? "Delivered" : "Pending";

    mysqli_query($conn,"UPDATE orders SET status='$newStatus' WHERE id=$id");
}

/* ✅ UPDATED QUERY (JOIN) */
$result = mysqli_query($conn,"
SELECT 
orders.id,
orders.customer,
orders.total_amount,
orders.payment_method,
orders.status,
order_items.product_name,
order_items.qty,
order_items.price
FROM orders
JOIN order_items 
ON orders.id = order_items.order_id
ORDER BY orders.id DESC
");
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Orders</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet">

<style>
*{ font-family:'Playfair Display',serif; }
body{ background:#fdf6f0; }

.navbar{
background:#f8e8d8 !important;
border-radius:0.5cm;
}

.admin-hero{
background:linear-gradient(rgba(253,246,240,0.4),rgba(253,246,240,0.2)), 
url("image1.png") center/cover no-repeat;
height:300px;
display:flex;
align-items:center;
justify-content:center;
text-align:center;
}

.section{ margin-top:60px; }

.admin-card{
border-radius:12px;
background:#fff3e6;
box-shadow:0 4px 12px rgba(0,0,0,0.05);
padding:20px;
}

.table{
background:white;
border-radius:10px;
overflow:hidden;
}

.btn-theme{
background:#fb6b2a;
color:white;
border-radius:20px;
border:none;
}

.btn-theme:hover{
background:#e55a1f;
}

.status{
padding:5px 10px;
border-radius:15px;
font-size:12px;
}

.pending{
background:orange;
color:white;
}

.delivered{
background:green;
color:white;
}
</style>
</head>

<body>

<!-- NAVBAR -->
<nav class="navbar navbar-expand-lg shadow-sm">
<div class="container-fluid px-3">

<a class="navbar-brand d-flex align-items-center" href="index.html">
<img src="foodlogo.png" width="40" height="40" class="me-2">
<span>Recipe<span style="color:orange;">Rush</span></span>
</a>

<div class="ms-auto">
<a href="admin-dashboard.php" class="nav-link d-inline">Dashboard</a>
<a href="logout.php" class="btn btn-warning ms-2">Logout</a>
</div>

</div>
</nav>

<!-- HERO -->
<section class="admin-hero">
<div>
<h1>Orders Management</h1>
<p>View and manage all customer orders</p>
</div>
</section>

<!-- TABLE -->
<section class="container section">

<h2 class="fw-bold mb-4 text-center">All Orders</h2>

<div class="admin-card">

<table class="table text-center">
<thead>
<tr>
<th>ID</th>
<th>Customer</th>
<th>Product</th>
<th>Qty</th>
<th>Price</th>
<th>Status</th>
<th>Action</th>
</tr>
</thead>

<tbody>

<?php while($row = mysqli_fetch_assoc($result)){ 
$statusClass = ($row['status']=="Delivered") ? "delivered" : "pending";
?>

<tr>
<td>#<?php echo $row['id']; ?></td>
<td><?php echo $row['customer']; ?></td>

<!-- ✅ FIXED PRODUCT -->
<td><?php echo $row['product_name']; ?></td>

<td><?php echo $row['qty']; ?></td>

<td>₹<?php echo $row['price']; ?></td>

<td>
<span class="status <?php echo $statusClass; ?>">
<?php echo $row['status']; ?>
</span>
</td>

<td>
<a href="?toggle=<?php echo $row['id']; ?>" class="btn btn-theme btn-sm">Toggle</a>
<a href="?delete=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
</td>

</tr>

<?php } ?>

</tbody>

</table>

</div>

</section>

<footer class="text-dark pt-4 pb-3 border-top text-center"
style="background:#f8e8d8; margin-top:80px;">
<div class="container">
<p>© 2026 Recipe Rush | All Rights Reserved</p>
</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>