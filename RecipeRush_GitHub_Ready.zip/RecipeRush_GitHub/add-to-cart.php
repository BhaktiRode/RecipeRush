<?php
session_start();

$conn = mysqli_connect("sql100.infinityfree.com","if0_41421772","ZhTezeJRMZeRYqb","if0_41421772_reciperush");

$user = "guest";

$product = $_POST['product'];
$price = $_POST['price'];
$qty = $_POST['qty'];

mysqli_query($conn,"INSERT INTO cart(username,product_name,price,qty)
VALUES('$user','$product','$price','$qty')");

echo "success";
?>