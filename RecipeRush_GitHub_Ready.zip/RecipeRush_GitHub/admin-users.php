<?php
error_reporting(0);
session_start();

if(!isset($_SESSION['admin'])){
    header("Location: admin-login.html");
    exit();
}

$conn = mysqli_connect("sql100.infinityfree.com","if0_41421772","ZhTezeJRMZeRYqb","if0_41421772_reciperush");

$result = mysqli_query($conn,"SELECT * FROM users");
?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>Admin Users</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&display=swap" rel="stylesheet">
<style>

*{
font-family:'Playfair Display',serif;
}

body{
background:#fdf6f0;
}

/* NAVBAR */
.navbar{
background:#f8e8d8 !important;
border-radius:0.5cm;
}

/* HERO */
.admin-hero{
background:linear-gradient(rgba(253,246,240,0.4),rgba(253,246,240,0.2)), 
url("image1.png") center/cover no-repeat;
height:300px;
display:flex;
align-items:center;
justify-content:center;
text-align:center;
}

/* SECTION */
.section{
margin-top:60px;
}

/* CARD */
.admin-card{
border-radius:12px;
background:#fff3e6;
box-shadow:0 4px 12px rgba(0,0,0,0.05);
padding:20px;
}

/* TABLE */
.table{
background:white;
border-radius:10px;
overflow:hidden;
}

/* BUTTON */
.btn-theme{
background:#fb6b2a;
color:white;
border-radius:20px;
border:none;
}

.btn-theme:hover{
background:#e55a1f;
}

</style>
</head>

<body>

<nav class="navbar p-3">
<div class="container-fluid">
<h4>Admin Panel</h4>
<div>
<a href="admin-dashboard.php" class="btn btn-secondary">Dashboard</a>
<a href="logout.php" class="btn btn-danger">Logout</a>
</div>
</div>
</nav>

<div class="container mt-5">

<h2 class="text-center mb-4">All Users</h2>

<div class="admin-card">

<table class="table table-bordered text-center">
<tr>
<th>ID</th>
<th>Username</th>
</tr>

<?php while($row = mysqli_fetch_assoc($result)){ ?>
<tr>
<td><?php echo $row['id']; ?></td>
<td><?php echo $row['username']; ?></td>
</tr>
<?php } ?>

</table>

</div>

</div>

</body>
</html>